"""
IBM Cloud Pak for Data API Client
Handles authentication and API requests for ODCS contracts and Data Product Exchange
"""

import copy  # noqa: I001 # Baseline
import json
import os
import requests
from collections.abc import Iterator
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional  # noqa: F401, UP035 # Baseline

if TYPE_CHECKING:
    import pyarrow as pa

try:
    import pyarrow.flight as _flight

    _FLIGHT_AVAILABLE = True
except ImportError:
    _FLIGHT_AVAILABLE = False


class CPDClient:
    """Client for IBM Cloud Pak for Data API operations"""

    def __init__(self, base_url: str, token: str):  # noqa: ANN204 # Baseline
        """
        Args:
            base_url: CPDaaS API base URL (value of ``CPDAAS_URL``).
            token:    Bearer token — either a pre-baked ``CPDAAS_TOKEN`` or one
                      obtained by exchanging ``CPDAAS_API_KEY`` via
                      :meth:`from_env`.
        """
        if not base_url:
            raise ValueError("base_url must not be empty")
        if not token:
            raise ValueError("token must not be empty")

        self.base_url = base_url
        self.token = token
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def from_env(cls, env_file: str | None = None) -> "CPDClient":
        """
        Build a :class:`CPDClient` from environment variables, optionally
        loading a ``.env`` file first.

        Resolution order for the bearer token:
        1. ``CPDAAS_TOKEN`` env-var (pre-baked token, used as-is).
        2. ``CPDAAS_API_KEY`` env-var — exchanged for a token via a POST to
           ``CPDAAS_AUTH_URL``.

        The ``.env`` file is parsed with plain file I/O (no ``python-dotenv``
        dependency) so this works on all Python versions and in any execution
        context (including ``python -c`` heredocs where
        ``dotenv.find_dotenv()`` fails due to missing caller frames).

        Args:
            env_file: Path to the ``.env`` file.  Defaults to a ``.env`` file
                      in the repository root (two directories above this
                      module).

        Returns:
            Authenticated :class:`CPDClient` instance.
        """
        # --- load .env without python-dotenv ---
        candidate_files = []
        if env_file:
            candidate_files.append(Path(env_file).resolve())
        else:
            # Check custom environment variable first
            if os.environ.get("ENV_FILE"):
                candidate_files.append(Path(os.environ["ENV_FILE"]).resolve())
            if os.environ.get("DOTENV_PATH"):
                candidate_files.append(Path(os.environ["DOTENV_PATH"]).resolve())

            # Check workspace root / cwd
            candidate_files.append(Path.cwd() / ".env")

            # Check repo root (3 levels above this file: scripts/api -> scripts -> skill -> root)
            candidate_files.append(
                Path(__file__).resolve().parent.parent.parent / ".env"
            )

            # Check skill directory (2 levels above: scripts/api -> scripts -> skill)
            candidate_files.append(Path(__file__).resolve().parent.parent / ".env")

        # Pick the first existing candidate
        resolved_env_file = next((f for f in candidate_files if f.is_file()), None)

        if resolved_env_file:
            with Path(resolved_env_file).open() as fh:
                for raw in fh:
                    line = raw.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    key, _, value = line.partition("=")
                    # Only set if not already present (env takes precedence)
                    os.environ.setdefault(key.strip(), value.strip())

        base_url = os.environ.get("CPDAAS_URL", "")
        if not base_url:
            raise ValueError("CPDAAS_URL is not set in the environment or .env file")

        # --- resolve bearer token ---
        token = os.environ.get("CPDAAS_TOKEN", "")
        if not token:
            auth_url = os.environ.get("CPDAAS_AUTH_URL", "")
            api_key = os.environ.get("CPDAAS_API_KEY", "")
            if not auth_url or not api_key:
                raise ValueError(
                    "No bearer token available. Set CPDAAS_TOKEN, or both "
                    "CPDAAS_AUTH_URL and CPDAAS_API_KEY in the environment / .env file."
                )
            resp = requests.post(  # noqa: S113 # Baseline
                auth_url,
                data={
                    "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
                    "apikey": api_key,
                },
            )
            resp.raise_for_status()
            token = resp.json()["access_token"]

        return cls(base_url=base_url, token=token)

    def get_contract(self, project_id: str, contract_id: str) -> Dict:  # noqa: UP006 # Baseline
        """
        Fetch ODCS contract by ID

        Args:
            project_id: IBM Cloud Pak for Data project ID
            contract_id: Contract ID

        Returns:
            Contract data as dictionary

        Raises:
            requests.HTTPError: If API request fails
        """
        url = f"{self.base_url}/data_quality/v4/projects/{project_id}/data_contracts/{contract_id}"
        response = requests.get(url, headers=self.headers)  # noqa: S113 # Baseline
        response.raise_for_status()
        return response.json()

    def update_contract(
        self,
        project_id: str,
        contract_id: str,
        contract_data: Dict,  # noqa: UP006 # Baseline
    ) -> Dict:  # noqa: UP006 # Baseline
        """
        Update ODCS contract

        Args:
            project_id: IBM Cloud Pak for Data project ID
            contract_id: Contract ID
            contract_data: Updated contract data (full contract response from API)

        Returns:
            Updated contract data as dictionary

        Raises:
            requests.HTTPError: If API request fails
        """
        url = f"{self.base_url}/data_quality/v4/projects/{project_id}/data_contracts/{contract_id}"

        # The update endpoint only accepts specific fields, filter out others.
        # Note: contract_json and contract_yaml are mutually exclusive — send only contract_yaml.
        payload = {
            "name": contract_data.get("name", ""),
            "contract_yaml": contract_data.get("contract_yaml", ""),
            "server_mappings": contract_data.get("server_mappings", []),
        }

        # Add type if present
        if "type" in contract_data:
            payload["type"] = contract_data["type"]

        response = requests.put(url, headers=self.headers, json=payload)  # noqa: S113 # Baseline
        response.raise_for_status()
        return response.json()

    def validate_contract(self, project_id: str, contract_data: Dict) -> Dict:  # noqa: UP006 # Baseline
        """
        Validate contract before updating

        Args:
            project_id: IBM Cloud Pak for Data project ID
            contract_data: Contract data to validate (full contract with contract_yaml field)

        Returns:
            Validation result as dictionary

        Raises:
            requests.HTTPError: If API request fails
        """
        url = f"{self.base_url}/data_quality/v4/projects/{project_id}/data_contracts_validation"

        # The validation endpoint expects plain text YAML content, not JSON
        contract_yaml = contract_data.get("contract_yaml", "")

        # Use text/plain content type
        headers = self.headers.copy()
        headers["Content-Type"] = "text/plain"

        response = requests.post(url, headers=headers, data=contract_yaml)  # noqa: S113 # Baseline
        response.raise_for_status()
        return response.json()

    def delete_contract(self, project_id: str, contract_id: str) -> bool:
        """
        Delete ODCS contract

        Args:
            project_id: IBM Cloud Pak for Data project ID
            contract_id: Contract ID to delete

        Returns:
            True if deletion was successful

        Raises:
            requests.HTTPError: If API request fails
        """
        url = f"{self.base_url}/data_quality/v4/projects/{project_id}/data_contracts?data_contract_ids={contract_id}"
        response = requests.delete(url, headers=self.headers)  # noqa: S113 # Baseline
        response.raise_for_status()
        return True

    def list_contracts(self, project_id: str) -> Dict:  # noqa: UP006 # Baseline
        """
        List all contracts in a project

        Args:
            project_id: IBM Cloud Pak for Data project ID

        Returns:
            List of contracts as dictionary

        Raises:
            requests.HTTPError: If API request fails
        """
        url = f"{self.base_url}/data_quality/v4/projects/{project_id}/data_contracts"
        response = requests.get(url, headers=self.headers)  # noqa: S113 # Baseline
        response.raise_for_status()
        return response.json()

    # -------------------------------------------------------------------------
    # Data Product Exchange API
    # -------------------------------------------------------------------------

    def get_data_product(self, data_product_id: str) -> Dict:  # noqa: UP006 # Baseline
        """
        Fetch a data product by ID via the Data Product Exchange API.

        Args:
            data_product_id: Data product ID

        Returns:
            Data product data as dictionary

        Raises:
            requests.HTTPError: If API request fails
        """
        url = (
            f"{self.base_url}/data_product_exchange/v1/data_products/{data_product_id}"
        )
        response = requests.get(url, headers=self.headers)  # noqa: S113 # Baseline
        response.raise_for_status()
        return response.json()

    def get_data_product_release(self, data_product_id: str, release_id: str) -> Dict:  # noqa: UP006 # Baseline
        """
        Fetch a specific release of a data product.

        Args:
            data_product_id: Data product ID
            release_id: Release ID (the full compound id, e.g. ``<asset_id>@<container_id>``)

        Returns:
            Release data as dictionary

        Raises:
            requests.HTTPError: If API request fails
        """
        url = (
            f"{self.base_url}/data_product_exchange/v1/data_products"
            f"/{data_product_id}/releases/{release_id}"
        )
        response = requests.get(url, headers=self.headers)  # noqa: S113 # Baseline
        response.raise_for_status()
        return response.json()

    def create_data_product_draft(self, data_product_id: str, payload: Dict) -> Dict:  # noqa: UP006 # Baseline
        """
        Create a new draft shell for a data product via POST.

        The payload should be minimal — only ``asset.container.id``,
        ``data_product.id``, and ``version`` are required.

        Args:
            data_product_id: Data product ID
            payload: Minimal draft payload as built by
                     :meth:`build_draft_post_payload`.

        Returns:
            Created draft data as dictionary (contains the new draft ID and
            the ``contract_terms[0].id`` needed for the PATCH call).

        Raises:
            requests.HTTPError: If API request fails
        """
        url = (
            f"{self.base_url}/data_product_exchange/v1/data_products"
            f"/{data_product_id}/drafts"
        )
        response = requests.post(url, headers=self.headers, json=payload)  # noqa: S113 # Baseline
        response.raise_for_status()
        return response.json()

    def get_data_product_draft(self, data_product_id: str, draft_id: str) -> Dict:  # noqa: UP006 # Baseline
        """
        Fetch a specific draft of a data product.

        Args:
            data_product_id: Data product ID
            draft_id: Draft ID (the full compound id, e.g. ``<asset_id>@<container_id>``)

        Returns:
            Draft data as dictionary

        Raises:
            requests.HTTPError: If API request fails
        """
        url = (
            f"{self.base_url}/data_product_exchange/v1/data_products"
            f"/{data_product_id}/drafts/{draft_id}"
        )
        response = requests.get(url, headers=self.headers)  # noqa: S113 # Baseline
        response.raise_for_status()
        return response.json()

    def patch_draft_contract_terms(
        self,
        data_product_id: str,
        draft_id: str,
        contract_terms_id: str,
        json_patch: list,
    ) -> Dict:  # noqa: UP006 # Baseline
        """
        Update the contract terms of an existing draft via PATCH.

        Uses RFC 6902 JSON Patch format (``Content-Type:
        application/json-patch+json``).  Use
        :meth:`build_contract_terms_patch` to produce the patch operations.

        Args:
            data_product_id: Data product ID
            draft_id: Full compound draft ID from ``create_data_product_draft``
                      response top-level ``id`` field
                      (e.g. ``<asset_id>@<container_id>``).
            contract_terms_id: Full compound contract terms ID from
                               ``draft["contract_terms"][0]["id"]``.
            json_patch: List of RFC 6902 patch operations as returned by
                        :meth:`build_contract_terms_patch`.

        Returns:
            Updated contract terms data as dictionary

        Raises:
            requests.HTTPError: If API request fails
        """
        url = (
            f"{self.base_url}/data_product_exchange/v1/data_products"
            f"/{data_product_id}/drafts/{draft_id}"
            f"/contract_terms/{contract_terms_id}"
        )
        headers = {**self.headers, "Content-Type": "application/json-patch+json"}
        response = requests.patch(url, headers=headers, json=json_patch)  # noqa: S113 # Baseline
        response.raise_for_status()
        return response.json()

    @staticmethod
    def build_draft_post_payload(release: Dict) -> Dict:  # noqa: UP006 # Baseline
        """
        Build the minimal POST payload to create a new draft shell.

        Keeps only ``asset.container.id``, ``data_product.id``, and
        ``version`` (with the revision component incremented).

        Args:
            release: Full release dict as returned by
                     :meth:`get_data_product_release`.

        Returns:
            Minimal payload ready to POST to the drafts endpoint.

        Raises:
            ValueError: If ``asset.container.id`` or ``data_product.id`` is
                        missing from ``release``.
        """
        # Increment revision (patch) version
        version_str = release.get("version", "1.0.0")
        parts = version_str.split(".")
        if len(parts) >= 3:  # noqa: PLR2004 # Baseline
            try:
                parts[2] = str(int(parts[2]) + 1)
                version_str = ".".join(parts)
            except ValueError:
                pass  # leave version unchanged if unparseable

        try:
            container_id = release["asset"]["container"]["id"]
            data_product_id = release["data_product"]["id"]
        except (KeyError, TypeError) as exc:
            raise ValueError(
                f"Release is missing required field {exc}; expected "
                "'asset.container.id' and 'data_product.id'"
            ) from exc

        return {
            "asset": {"container": {"id": container_id}},
            "data_product": {"id": data_product_id},
            "version": version_str,
        }

    @staticmethod
    def build_contract_yaml_patch(
        contract_yaml: str,
        dropped_columns: List[str],  # noqa: UP006 # Baseline
    ) -> str:
        """
        Remove dropped columns and all referencing quality rules from an ODCS
        contract YAML string, and increment the patch version.

        Used by the Contract Direct remediation path when a Data Product ID is
        absent but a Contract ID and Project ID are available.

        The following mutations are applied to the in-memory ODCS document:

        * ``schema[*].properties`` entries whose ``name`` matches any dropped
          column are removed entirely.
        * Quality rules inside surviving property entries
          (``properties[*].quality``) whose ``name`` or ``query`` contains any
          dropped column name are removed.
        * Table-level quality rules (``schema[*].quality``) whose ``name`` or
          ``query`` contains any dropped column name are removed.
        * The top-level ``version`` field has its patch component incremented
          (e.g. ``1.0.0`` → ``1.0.1``).

        Args:
            contract_yaml: Raw ODCS YAML string as returned by
                           :meth:`get_contract` (the ``contract_yaml`` field).
            dropped_columns: Column names to purge.  Each name is matched
                             case-sensitively as a substring against property
                             ``name``, rule ``name``, and rule ``query`` fields.

        Returns:
            Updated ODCS YAML string ready to be placed in the ``contract_yaml``
            field of the :meth:`update_contract` PUT payload.

        Raises:
            ValueError: If ``contract_yaml`` cannot be parsed as valid YAML.
            ImportError: If the ``PyYAML`` (``yaml``) package is not installed.
        """
        try:
            import yaml  # PyYAML — present in the project's requirements
        except ImportError:
            raise ImportError(  # noqa: B904 # Baseline
                "PyYAML is required for build_contract_yaml_patch. "
                "Install it with: pip install pyyaml"
            )

        doc = yaml.safe_load(contract_yaml)
        if not isinstance(doc, dict):
            raise ValueError("contract_yaml did not parse to a YAML mapping.")

        cols = dropped_columns

        # Increment patch version (e.g. "1.0.0" → "1.0.1")
        version_str = str(doc.get("version", "1.0.0"))
        parts = version_str.split(".")
        if len(parts) >= 3:  # noqa: PLR2004 # Baseline
            try:
                parts[2] = str(int(parts[2]) + 1)
                doc["version"] = ".".join(parts)
            except ValueError:
                pass  # leave version unchanged if unparseable

        def _refs_dropped(rule: dict) -> bool:
            """Return True if the rule name or query references any dropped col."""
            return any(
                col in rule.get("name", "") or col in rule.get("query", "")
                for col in cols
            )

        for schema_entry in doc.get("schema", []):
            # Remove property entries for dropped columns; clean rules in others
            new_props = []
            for prop in schema_entry.get("properties", []):
                if prop.get("name") in cols:
                    continue
                prop["quality"] = [
                    q for q in prop.get("quality", []) if not _refs_dropped(q)
                ]
                new_props.append(prop)
            schema_entry["properties"] = new_props

            # Remove table-level quality rules referencing any dropped column
            schema_entry["quality"] = [
                q for q in schema_entry.get("quality", []) if not _refs_dropped(q)
            ]

        return yaml.dump(
            doc, default_flow_style=False, allow_unicode=True, sort_keys=False
        )

    @staticmethod
    def build_contract_terms_patch(release: Dict, dropped_columns: List[str]) -> list:  # noqa: UP006 # Baseline
        """
        Build the RFC 6902 JSON Patch operations for
        ``patch_draft_contract_terms``.

        Produces one ``replace`` operation per schema entry using the path
        ``/schema/{asset_id}``, which is the format accepted by the Data
        Product Exchange PATCH endpoint.  Each schema entry is deep-copied
        from the release and cleaned:

        * Property entries whose ``name`` matches any dropped column are removed
        * Any quality rule referencing any dropped column by name or query is
          removed from ``properties[*].quality`` and ``quality``

        Args:
            release: Full release dict as returned by
                     :meth:`get_data_product_release`.
            dropped_columns: Column names to purge (each matched as substring
                             against property ``name``, rule ``name``, and rule
                             ``query``).

        Returns:
            List of RFC 6902 patch operations ready to pass to
            :meth:`patch_draft_contract_terms`.

        Raises:
            ValueError: If a schema entry has no ``asset_id``.
        """
        if not release.get("contract_terms"):
            return []

        ct = release["contract_terms"][0]
        cols = dropped_columns
        ops = []

        for schema_entry in ct.get("schema", []):
            try:
                asset_id = schema_entry["asset_id"]
            except KeyError as exc:
                raise ValueError(
                    "Schema entry in release contract_terms is missing required "
                    "field 'asset_id'"
                ) from exc
            cleaned = copy.deepcopy(schema_entry)

            # Remove properties for dropped columns; clean rules in others
            new_props = []
            for prop in cleaned.get("properties", []):
                if prop.get("name") in cols:
                    continue
                prop["quality"] = [
                    q
                    for q in prop.get("quality", [])
                    if not any(
                        col in q.get("name", "") or col in q.get("query", "")
                        for col in cols
                    )
                ]
                new_props.append(prop)
            cleaned["properties"] = new_props

            # Remove table-level quality rules referencing any dropped column
            cleaned["quality"] = [
                q
                for q in cleaned.get("quality", [])
                if not any(
                    col in q.get("name", "") or col in q.get("query", "")
                    for col in cols
                )
            ]

            ops.append(
                {"op": "replace", "path": f"/schema/{asset_id}", "value": cleaned}
            )

        return ops

    # -------------------------------------------------------------------------
    # Connection Assets API
    # -------------------------------------------------------------------------

    def _flight_open(
        self,
        asset_id: str,
        project_id: str,
        flight_host: str | None,
        flight_port: int,
    ) -> tuple[Any, Any, Any]:
        """
        Connect to the Flight service and fetch the ``FlightInfo`` for an asset.

        Returns:
            ``(client, call_options, flight_info)``.  The caller owns ``client``
            and must close it.

        Raises:
            ImportError: If ``pyarrow`` is not installed.
            ValueError: If the Flight server returns no endpoints for the asset.
            pyarrow.flight.FlightError: If the Flight call fails.
        """
        if not _FLIGHT_AVAILABLE:
            raise ImportError(
                "pyarrow is required for Flight support. "
                "Install it with: pip install pyarrow"
            )

        from urllib.parse import urlparse

        host = (
            flight_host
            or os.environ.get("FLIGHT_HOST")
            or urlparse(self.base_url).hostname
        )
        flight_port = int(os.environ.get("FLIGHT_PORT", flight_port))

        client = _flight.connect(_flight.Location.for_grpc_tls(host, flight_port))
        auth_headers = [(b"authorization", f"Bearer {self.token}".encode())]
        opts = _flight.FlightCallOptions(headers=auth_headers)

        cmd = json.dumps(
            {
                "asset_id": asset_id,
                "project_id": project_id,
                "context": "source",
            }
        ).encode()

        info = client.get_flight_info(
            _flight.FlightDescriptor.for_command(cmd), options=opts
        )
        if not info.endpoints:
            client.close()
            raise ValueError(
                f"Flight server returned no endpoints for asset {asset_id} "
                f"in project {project_id}"
            )
        return client, opts, info

    def iter_asset_data_flight(
        self,
        asset_id: str,
        project_id: str,
        flight_host: str | None = None,
        flight_port: int = 443,
    ) -> Iterator["pa.RecordBatch"]:
        """
        Stream row data for a connection asset via Apache Arrow Flight, one
        ``pyarrow.RecordBatch`` at a time, so the full result is never held in
        memory.  Every endpoint returned by the server is read in order.

        Each batch carries the asset schema in ``batch.schema`` (including
        field metadata), so a caller that only needs the schema or a sample
        can take the first batch and stop::

            with contextlib.closing(client.iter_asset_data_flight(a, p)) as batches:
                first = next(batches, None)

        Closing the generator (or exhausting it) closes the Flight connection.
        If the asset has no rows the generator yields nothing.

        Args:
            asset_id:    Asset ID (from the parent Git issue).
            project_id:  Project ID (from the parent Git issue).
            flight_host: Flight gRPC host. Defaults to the hostname of
                         ``self.base_url``.
            flight_port: Flight gRPC port (default: 443).

        Yields:
            ``pyarrow.RecordBatch`` objects in server order.

        Raises:
            ImportError: If ``pyarrow`` is not installed.
            ValueError: If the Flight server returns no endpoints for the asset.
            pyarrow.flight.FlightError: If the Flight call fails.
        """
        client, opts, info = self._flight_open(
            asset_id, project_id, flight_host, flight_port
        )
        try:
            for endpoint in info.endpoints:
                reader = client.do_get(endpoint.ticket, options=opts)
                for chunk in reader:
                    yield chunk.data
        finally:
            client.close()
